import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Console {
	FileSystem fileSystem;
	public Console()
	{
		fileSystem = new FileSystem();
	}
	
	public void menu() throws InterruptedException
	{
		int choice = 0;
		Set<String> employeeList;
		Scanner scanner = new Scanner(System.in);
		Employee employee;
		
		System.out.println("1 Add Employees");
		System.out.println("2 Get All Employee Id's");
		System.out.println("3 Get Employee Information based on Id");
		System.out.println("4 Update Employee information");
		System.out.println("5 A daemon should consolidate all the same transaction files in to one file");
		choice = new Integer(scanner.nextLine());
		switch(choice)
		{
		case 1:
		case 4:
			fileSystem.addEmployees();
			break;
		case 2:
			employeeList = fileSystem.getEmployeeIDs();
			for(String employeeID : employeeList)
				System.out.println(employeeID);
			break;
		case 3:
			System.out.println("Enter employee id to find details");
			String id = scanner.nextLine();
			employee = fileSystem.getEmployee(id);
			System.out.println(employee);
			break;
		case 5:
			fileSystem.consolidateAllEmployeeFiles();
		}	
	}
}
