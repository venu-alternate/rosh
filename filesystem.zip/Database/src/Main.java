
public class Main {
	
	public static void main(String[] args) throws InterruptedException
	{
		Console console = new Console();
		
		console.menu();
	}
	
}
