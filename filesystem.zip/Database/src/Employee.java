import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

public class Employee {
	private static int newID = 0;
	private int myID;
	private Timestamp currentTimeStamp;
	private Map<String, Object> propertyMap;
	private Scanner scanner;
	private List<String> propertiesInOrder;
	
	public Employee(){
		updateEmployee();
		propertyMap = new HashMap<String, Object>();
		propertiesInOrder = new ArrayList<String>();
		scanner = new Scanner(System.in);
	}

	private synchronized void updateEmployee() {
		newID = newID + 1;
		this.myID = newID;
		this.currentTimeStamp = new Timestamp(Calendar.getInstance().getTime().getTime());
	}

	public void addProperties() {
		addDefaultProperties();
		addDynamicProperties();
	}

	private void addDefaultProperties() {
		propertyMap.put("ID", this.myID+"");
		propertiesInOrder.add("ID");
		
		propertyMap.put("TimeStamp", currentTimeStamp);
		propertiesInOrder.add("TimeStamp");
		
		System.out.println("Enter Name of employee" + this.myID + " :");
		propertyMap.put("Name", scanner.nextLine());
		propertiesInOrder.add("Name");
		
		System.out.println("Enter Job of employee" + this.myID + "  :");
		propertyMap.put("Job", scanner.nextLine());
		propertiesInOrder.add("Job");
	}

	private void addDynamicProperties() {
		boolean morePropertyEntries;
		
		do{
			System.out.println("Would you like to enter more details for employee" + this.myID + " (Y/N)");
			String b = scanner.nextLine();
			morePropertyEntries = b.equals("y");

			if(!morePropertyEntries)
				break;

			System.out.println("Enter propetrty name for employee" + this.myID + " :");
			String property = scanner.nextLine();
			System.out.println("Enter Value of " + property +"for employee" + this.myID + " :");
			String value = scanner.nextLine();			
			propertyMap.put(property, value);
			propertiesInOrder.add(property);
		}while(morePropertyEntries);

		return;
	}
	
	public Object getProperty(String key){
		Object value;
		value = propertyMap.get(key);
		return value;
	}
	
	@Override
	public String toString(){
		String returnString = "";
		
		for(String key : propertiesInOrder)
		{
			returnString += key + "\t:\t" + propertyMap.get(key) + System.lineSeparator();
		}
		return returnString;
	}

	public Employee(ArrayList<File> files) {
		
		setConsolidateInfo(files);
		
	}

	private void setConsolidateInfo(ArrayList<File> files) {
		propertyMap = new HashMap<String, Object>();
		propertiesInOrder = new  ArrayList<String>();
		Collections.reverse(files);
		for(File file : files)
		{
			setInfoFromFile(file);
		}
	}

	private void setInfoFromFile(File file) {
		try {
			BufferedReader readerFromfile = new BufferedReader(new FileReader(file));
			Stream<String> lines = readerFromfile.lines();
			for(Object line : lines.toArray()){
				String splittedString[] = line.toString().split(":");
				Object o = propertyMap.put(splittedString[0].trim(), splittedString[1].trim()) == null ? propertiesInOrder.add(splittedString[0].trim()) : null;				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return;
	}
}