import java.io.File; 
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;


public class FileSystem {

	public class DaemonThread extends Thread{
		public void run(){
			Set<String> IDs = getEmployeeIDs();
			for(String ID : IDs)
			{
				storeEmployeeToDiskAs(getEmployee(ID),basePath + "\\" + ID + "_final.txt");
			}
		}
	}

	private static int employeeID;
	private File fileSystem;
	private String basePath;
	private Scanner scanner;
	
	static{
		employeeID = 0;
	}
	
	public FileSystem()
	{
		basePath = "D:\\mystuff\\rosh\\fileSystem";
		fileSystem = new File(basePath);
		scanner = new Scanner(System.in);
	}
	
	public void addEmployees() {
		boolean moreEmployeeEntries = true;
		
		while(moreEmployeeEntries){
			new Thread(){
				public void run(){
					addEmployee();
				}

				private void addEmployee() {
					Employee newEmployee;

					newEmployee = createEmployee();
					String fileName = basePath + newEmployee.getProperty("ID").toString() + "_" + ((Timestamp) newEmployee.getProperty("TimeStamp")).getTime() + ".txt";
					storeEmployeeToDiskAs(newEmployee, fileName);
				}

				private synchronized Employee createEmployee() {
					Employee newEmployee;
					newEmployee = new Employee();
			
					newEmployee.addProperties();
					return newEmployee;
				}
			}.start();
			System.out.println("Would you like to enter another employee details (Y/N)");
			String  b = scanner.nextLine();
			moreEmployeeEntries = b.equals("y");
		}
	}
	
	private void storeEmployeeToDiskAs(Employee newEmployee, String fileName) {
		File newEmployeeFile = new File(fileName);
		try {
			newEmployeeFile.createNewFile();
			FileWriter fop = new FileWriter(newEmployeeFile, true);
			
			fop.write(newEmployee.toString());
			fop.flush();
			fop.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Set<String> getEmployeeIDs() {
		File baseDirectory = new File(basePath);
		HashSet<String> files = new HashSet<String>();
		for(File f : baseDirectory.listFiles())
		{
			files.add((f.getName().replace(basePath, "").split("_"))[0]);
			
		}
		return files;
	}

	public Employee getEmployee(String id) {
		File baseDirectory = new File(basePath);
		ArrayList<File> files = new ArrayList<File>();
		Employee employee = null;
		
		for(File f : baseDirectory.listFiles())
		{
			if((f.getName().replace(basePath, "").split("_"))[0].equals(id))
				files.add(f);
		}
		
		if(!files.isEmpty())
		{
			employee = new Employee(files);
		}
		
		return employee;
	}

	public void consolidateAllEmployeeFiles() throws InterruptedException {
		DaemonThread daemonThread = new DaemonThread();
		daemonThread.setDaemon(true);
		daemonThread.start();
		daemonThread.join();
	}

}
