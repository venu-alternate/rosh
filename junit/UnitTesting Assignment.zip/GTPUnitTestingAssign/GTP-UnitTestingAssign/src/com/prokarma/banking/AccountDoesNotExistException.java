package com.prokarma.banking;

public class AccountDoesNotExistException extends Exception {
	static final long serialVersionUID = 1L; 
}
