package com.prokarma.junit.atm;

public interface MessageSender {
	
	public boolean send (String message);

}
