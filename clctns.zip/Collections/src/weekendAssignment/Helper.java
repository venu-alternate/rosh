package weekendAssignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Helper {

	public List<String> readFile(String fileName) throws IOException{
		List<String> returnList = new ArrayList<String>(20);
		InputStream is = this.getClass().getClassLoader().getResourceAsStream(fileName);
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		for(String tempLine=reader.readLine();tempLine!=null;tempLine=reader.readLine()){
			returnList.add(tempLine);
		}
		return returnList;
	}

}
