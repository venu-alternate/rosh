package weekendAssignment;

import java.io.IOException;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) throws IOException
	{
		BooksCatalogue catalogue = new BooksCatalogue();
	
		ArrayList<Book> catalogueSortedByBookName = new ArrayList<Book>(catalogue.books);
		catalogueSortedByBookName.sort(Book.BookNameComparator);
		System.out.println("catalogueSortedByBookName");
		BooksCatalogue.print(catalogueSortedByBookName);

		ArrayList<Book> catalogueSortedByAuthor = new ArrayList<Book>(catalogue.books);
		catalogueSortedByAuthor.sort(Book.AuthorComparator);
		System.out.println();
		System.out.println("catalogueSortedByAuthor");
		BooksCatalogue.print(catalogueSortedByAuthor);

		ArrayList<Book> catalogueSortedByRelatedTechnology  = new ArrayList<Book>(catalogue.books);
		catalogueSortedByRelatedTechnology.sort(Book.RelatedTechnologyComparator);  
		System.out.println();
		System.out.println("catalogueSortedByRelatedTechnology");
		BooksCatalogue.print(catalogueSortedByRelatedTechnology);

	}
}
