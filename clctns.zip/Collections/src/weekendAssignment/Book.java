package weekendAssignment;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

public class Book {

	private String BOOK_NAME;
	private ArrayList<String> AUTHORS;
	private String RELATED_TECHNOLOGY;
	
	public static Comparator<Book> BookNameComparator = new Comparator<Book>() {
		public int compare(Book book1, Book book2) 
		{
			String book1Name = book1.getBOOK_NAME();
			String book2Name = book2.getBOOK_NAME();

			return book1Name.compareToIgnoreCase(book2Name);
		}
	};

	public static Comparator<Book> AuthorComparator = new Comparator<Book>() {
		public int compare(Book book1, Book book2) 
		{
			String book1Author = book1.getAUTHORS().toString();
			String book2Author = book2.getAUTHORS().toString();

			return book1Author.compareToIgnoreCase(book2Author);
		}
	};

	public static Comparator<Book> RelatedTechnologyComparator = new Comparator<Book>() {
		public int compare(Book book1, Book book2) 
		{
			String book1RelatedTechnology = book1.getREALTED_TECHNOLOGY();
			String book2RelatedTechnology = book2.getREALTED_TECHNOLOGY();

			return book1RelatedTechnology.compareToIgnoreCase(book2RelatedTechnology);
		}
	};

	public List<String> getAUTHORS() {
		return AUTHORS;
	}

	public String getREALTED_TECHNOLOGY() {
		return RELATED_TECHNOLOGY;
	}

	public String getBOOK_NAME() {
		return BOOK_NAME;
	}

	public Book(String row)
	{
		String[] details = row.split(",");
		
		BOOK_NAME = details[0];
		HashSet<String> authors = new HashSet<String>();
		for(String author : details[1].split(";"))
			authors.add(author);
		AUTHORS = new ArrayList<String>(authors);
		AUTHORS.sort(new Comparator<String>(){

			@Override
			public int compare(String string1, String string2) {
				return string1.compareToIgnoreCase(string2);
			}
			
		});
		RELATED_TECHNOLOGY = details[2];
	}
	
	@Override
	public boolean equals(Object book)
	{
		boolean equalFlag = false;
		if((this.BOOK_NAME.equals(((Book)book).BOOK_NAME)) && 
				(this.AUTHORS.equals(((Book)book).AUTHORS)) && 
						(this.RELATED_TECHNOLOGY.equals(((Book)book).RELATED_TECHNOLOGY))) 
			equalFlag = true;
		return equalFlag;
	}
	
	@Override
	public int hashCode()
	{
		return new String(this.BOOK_NAME+this.AUTHORS.toString()+this.RELATED_TECHNOLOGY).hashCode();
	}
	
	@Override
	public String toString()
	{
		return "Book :" + BOOK_NAME + "\t\t\tAuthor/s :" + AUTHORS + "\t\t\tRelated Technology :" + RELATED_TECHNOLOGY;
	}
}
