package weekendAssignment;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BooksCatalogue {

	public Set<Book> books;
	
	public static void print(List<Book> catalogue)
	{
		for(Book book : catalogue)
			System.out.println(book);
		
		return;
	}

	public BooksCatalogue() throws IOException
	{
		this("CollectionsWeekendAssignmentInputFile.txt");
	}

	public BooksCatalogue(String fileName) throws IOException 
	{
		List<String> rows = new Helper().readFile(fileName);
		books = new HashSet<Book>();
		
		for(String row : rows)
		{
			books.add(new Book(row));
		}
	}
}
